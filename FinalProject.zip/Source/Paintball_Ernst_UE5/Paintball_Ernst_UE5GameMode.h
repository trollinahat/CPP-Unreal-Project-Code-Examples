// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "Paintball_Ernst_UE5GameMode.generated.h"

UCLASS(minimalapi)
class APaintball_Ernst_UE5GameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	APaintball_Ernst_UE5GameMode();
};



