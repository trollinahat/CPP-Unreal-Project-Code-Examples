// Copyright Epic Games, Inc. All Rights Reserved.

#include "Paintball_Ernst_UE5GameMode.h"
#include "Paintball_Ernst_UE5Character.h"
#include "UObject/ConstructorHelpers.h"

APaintball_Ernst_UE5GameMode::APaintball_Ernst_UE5GameMode()
	: Super()
{
	// set default pawn class to our Blueprinted character
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnClassFinder(TEXT("/Game/FirstPerson/Blueprints/BP_FirstPersonCharacter"));
	DefaultPawnClass = PlayerPawnClassFinder.Class;

}
