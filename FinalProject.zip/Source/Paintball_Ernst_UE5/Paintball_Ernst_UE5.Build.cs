// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;

public class Paintball_Ernst_UE5 : ModuleRules
{
	public Paintball_Ernst_UE5(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "HeadMountedDisplay", "Niagara" });
	}
}
