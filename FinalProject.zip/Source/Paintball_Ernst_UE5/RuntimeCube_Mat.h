// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RuntimeCube_Mat.generated.h"

UCLASS()
class PAINTBALL_ERNST_UE5_API ARuntimeCube_Mat : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ARuntimeCube_Mat();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

private:
	//Create Static Mesh and Material Nodes

	UPROPERTY(VisibleAnywhere)
	UStaticMeshComponent* Mesh;
		
	UMaterialInterface* Material;

};
