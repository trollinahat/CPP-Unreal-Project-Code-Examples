// Copyright Epic Games, Inc. All Rights Reserved.

#include "Paintball_Ernst_UE5.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Paintball_Ernst_UE5, "Paintball_Ernst_UE5" );
 