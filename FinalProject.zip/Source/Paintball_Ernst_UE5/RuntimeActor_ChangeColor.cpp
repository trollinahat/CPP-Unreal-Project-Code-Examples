// Fill out your copyright notice in the Description page of Project Settings.

#include "RuntimeActor_ChangeColor.h"
#include "Math/Color.h"

// Sets default values
ARuntimeActor_ChangeColor::ARuntimeActor_ChangeColor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//Initialze Mesh and Declare it as Root Component
	Mesh = CreateDefaultSubobject<UStaticMeshComponent>("Mesh");
	RootComponent = Mesh;


	//Get Material for the first slot -- MUST BE MATERIAL INSTANCE
	Material = Mesh->GetMaterial(0);

}

// Called when the game starts or when spawned
void ARuntimeActor_ChangeColor::BeginPlay()
{
	Super::BeginPlay();

	DynamicMaterial = UMaterialInstanceDynamic::Create(Material, this);

	//Setting Material Slot 1 to be our dynamic version, allowing runtime changes
	Mesh->SetMaterial(0, DynamicMaterial);


	DynamicMaterial->SetVectorParameterValue(TEXT("A Color"), FLinearColor::MakeRandomColor());


	DynamicMaterial->SetVectorParameterValue(TEXT("B Color"), FLinearColor::MakeRandomColor());
}

// Called every frame
void ARuntimeActor_ChangeColor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	//Set Material Parameters based off of parameters that are found in the material instance I created.

	float blend = 0.5f + (FMath::Cos(GetWorld()->TimeSeconds) / 2);

	DynamicMaterial->SetScalarParameterValue(TEXT("Blend"), blend);
}

