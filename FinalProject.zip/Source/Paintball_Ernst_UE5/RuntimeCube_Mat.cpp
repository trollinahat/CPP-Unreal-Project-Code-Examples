// Fill out your copyright notice in the Description page of Project Settings.

#include "RuntimeCube_Mat.h"
#include "Math/Color.h"

// Sets default values
ARuntimeCube_Mat::ARuntimeCube_Mat()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	
	//Initialze Mesh and Declare it as Root Component
	Mesh = CreateDefaultSubobject<UStaticMeshComponent>("Mesh");
	RootComponent = Mesh;

}

// Called when the game starts or when spawned
void ARuntimeCube_Mat::BeginPlay()
{
	Super::BeginPlay();

	//Get Material for the first slot -- MUST BE MATERIAL INSTANCE
	Material = Mesh->GetMaterial(0);

	UMaterialInstanceDynamic* DynamicMaterial = UMaterialInstanceDynamic::Create(Material, this);

	//Setting Material Slot 1 to be our dynamic version, allowing runtime changes
	Mesh->SetMaterial(0, DynamicMaterial);

	//Set Material Parameters based off of parameters that are found in the material instance I created.

	//Base Tint is RGBA and must be a VectorParameter Value
	DynamicMaterial->SetVectorParameterValue(TEXT("Base Tint"), FLinearColor::White);

	DynamicMaterial->SetVectorParameterValue(TEXT("A Color"), FLinearColor::MakeRandomColor());

	DynamicMaterial->SetScalarParameterValue(TEXT("A Intensity"), 50);

	DynamicMaterial->SetScalarParameterValue(TEXT("B Intensity"), 0);

	DynamicMaterial->SetScalarParameterValue(TEXT("Fresnel Intensity"), 20);

}

// Called every frame
void ARuntimeCube_Mat::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

